import os.path

app_path=os.path.dirname(__file__)
content_path=os.path.join(app_path,"content")
static_path=os.path.join(app_path,"static")
bot_path=os.path.join(static_path,"botpath")
