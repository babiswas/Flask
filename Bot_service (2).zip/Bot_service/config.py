class Config:
    SECRET_KEY="Bapans APP"
    SQLALCHEMY_DATABASE_URI="postgresql://postgres:36network@localhost/smart_author"
    